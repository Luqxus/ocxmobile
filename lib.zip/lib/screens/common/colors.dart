import 'package:flutter/material.dart';

Color primary = const Color(0xFF6193FF);
Color secondary = const Color(0xFFBBDAFF);
Color textPrimary = const Color(0xFF000000);
Color textSecondary = const Color(0xFF838383);
