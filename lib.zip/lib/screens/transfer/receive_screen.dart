import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ocx_mobile/bloc/transfer/bloc.dart';
import 'package:ocx_mobile/bloc/transfer/event.dart';
import 'package:ocx_mobile/bloc/wallet/bloc.dart';
import 'package:ocx_mobile/screens/common/colors.dart';
import 'package:ocx_mobile/screens/transfer/bloc/bloc.dart';
import 'package:ocx_mobile/screens/transfer/bloc/state.dart';
import 'package:ocx_mobile/screens/transfer/widgets/transaction_type.dart';

class ReceiveScreen extends StatelessWidget {
  const ReceiveScreen({super.key});

  // final TextEditingController _amountController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        child: Column(
          children: [
            // backbutton
            _backButton(context),

            // transaction type selector
            _transactionTypeSelector(),

            // selected transaction type builder
            _transactionTypeBuilder(context),
          ],
        ),
      ),
    );
  }

  _transactionTypeSelector() {
    return BlocBuilder<TxTypeBloc, TxTypeState>(builder: (context, state) {
      return Row(
        children: [
          TextButton(
            style: TextButton.styleFrom(
              backgroundColor: (state.index == 0) ? primary : secondary,
            ),
            onPressed: () {},
            child: const Text("QR"),
          ),
          TextButton(
            style: TextButton.styleFrom(
              backgroundColor: (state.index == 1) ? primary : secondary,
            ),
            onPressed: () {},
            child: const Text("NFC"),
          ),
        ],
      );
    });
  }

  _transactionTypeBuilder(BuildContext context) {
    return BlocBuilder<TxTypeBloc, TxTypeState>(
      builder: (context, state) {
        if (state.index == 1) {
          return const QRCodeAddress();
        }
        return BlocProvider(
          create: (context) => TransferBloc(
            BlocProvider.of<WalletBloc>(context).walletRepository,
          )..add(ReceiveNFC()),
          child: const NFCScanner(),
        );
      },
    );
  }

  _backButton(BuildContext ctx) {
    // back button
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        IconButton(
          onPressed: () {
            Navigator.pop(ctx);
          },
          icon: Icon(
            Icons.clear_rounded,
            color: textPrimary,
          ),
        ),
      ],
    );
  }
}
